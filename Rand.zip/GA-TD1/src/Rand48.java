import java.math.BigInteger;

public class Rand48 {
	
	public static BigInteger rand(BigInteger a, BigInteger c, BigInteger m, BigInteger graine){
		BigInteger val = graine.multiply(a);
		val = val.add(c);
		return val.mod(m);
	}
	
	public static void rand48(BigInteger graine){
		for (int i = 0; i < 10; i++) {
			graine = Rand48.rand(new BigInteger("25214903917"), new BigInteger("11"), new BigInteger("2").pow(48), graine);
			System.out.println(graine);
		}
		 
	}
	
	public static void rand48Java(){
		BigInteger graine = new BigInteger("156079716630527");
		BigInteger val;
		int bitFort;

		for (int i = 0; i < 10; i++) {
			graine = Rand48.rand(new BigInteger("25214903917"), new BigInteger("11"), new BigInteger("2").pow(48), graine);
			//System.out.println(graine);
			val = graine.divide(new BigInteger("2").pow(16));
			bitFort = val.divide(new BigInteger("2").pow(31)).intValue();
			//System.out.println(bitFort);
			if(bitFort == 0){
				val = val.mod(new BigInteger("2").pow(31));
				System.out.println(val);
			}
			else
				System.out.println(val.subtract(new BigInteger("2").pow(32)));
		}
		
	}
	
	
	
	public static void main(String[] args) {
		Rand48.rand48Java();
	}
	

}
