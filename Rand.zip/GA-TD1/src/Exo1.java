import java.math.BigInteger;

public class Exo1 {
	
	public static BigInteger neumann(BigInteger graine){
		BigInteger carre = graine.multiply(graine);
		return carre.divide(new BigInteger("100000")).mod(new BigInteger("10000000000"));
		
	}
	
	

	public static void main(String[] args) {
		BigInteger val = new BigInteger("1578750190");
		for (int i = 0; i < 10; i++) {
			val = neumann(val);
			System.out.println(val);
		}
		
	}
}
