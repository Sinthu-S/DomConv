import java.math.BigInteger;

public class Exo2 {
	
	
	public static BigInteger neumann2(BigInteger graine){
		BigInteger carre = graine.multiply(graine);
		return carre.divide(new BigInteger("10")).mod(new BigInteger("100"));
		
	}
	
	public static void main(String[] args) {
		BigInteger val = new BigInteger("69");
		BigInteger result = new BigInteger("00");
		int n=0;
		for (int i = 0; i < 100; i++) {
			val = neumann2(val);
			System.out.println(val);
			if(!val.equals(result))
				n++;
			
		}
		System.out.println(n);
		
	}

}
